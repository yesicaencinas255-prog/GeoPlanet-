// ============================================================
// GEO PLANET - personalizacion_nombre.js
// ============================================================

const btnAtras           = document.getElementById("btnAtras");
const inputNombreJugador = document.getElementById("nombreJugador");
const btnConfirmarNombre = document.getElementById("btnConfirmarNombre");
const mensajeNombre      = document.getElementById("mensajeNombre");

// BOTÓN ATRÁS: Regresa a la pantalla de registro
btnAtras.addEventListener("click", function () {
  window.location.href = "pantallaregistro.html"; 
});

// MOSTRAR MENSAJES
function mostrarMensaje(texto, tipo) {
  mensajeNombre.textContent = texto;
  mensajeNombre.classList.remove("error", "exito");
  mensajeNombre.classList.add(tipo);
}

// CONFIRMAR Y GUARDAR NOMBRE
btnConfirmarNombre.addEventListener("click", function () {
  const nombre = inputNombreJugador.value.trim();

  if (!nombre) {
    mostrarMensaje("¡Por favor ingresa tu nombre!", "error");
    return;
  }

  // Guarda en localStorage sin borrar el registro
  localStorage.setItem("nombreJugador", nombre);
  mostrarMensaje("¡Nombre guardado!", "exito");

  setTimeout(function () {
    // Reemplaza por la pantalla del juego/mapa a la que quieras ir
    window.location.href = "mapa.html";
  }, 1000);
});
// ============================================================
// GEO PLANET - personalizacion_nombre.js
// ============================================================

document.addEventListener("DOMContentLoaded", function () {
  const btnAtras           = document.getElementById("btnAtras");
  const inputNombreJugador = document.getElementById("nombreJugador");
  const btnConfirmarNombre = document.getElementById("btnConfirmarNombre");
  const mensajeNombre      = document.getElementById("mensajeNombre");

  // BOTÓN ATRÁS: Regresa a la pantalla de registro
  if (btnAtras) {
    btnAtras.addEventListener("click", function () {
      window.location.href = "pantallaregistro.html"; 
    });
  }

  // MOSTRAR MENSAJES DE ERROR / ÉXITO
  function mostrarMensaje(texto, tipo) {
    if (mensajeNombre) {
      mensajeNombre.textContent = texto;
      mensajeNombre.className = "mensaje-nombre " + tipo;
    }
  }

  // CONFIRMAR Y GUARDAR NOMBRE
  if (btnConfirmarNombre) {
    btnConfirmarNombre.addEventListener("click", function () {
      const nombre = inputNombreJugador ? inputNombreJugador.value.trim() : "";

      if (!nombre) {
        mostrarMensaje("¡Por favor ingresa tu nombre!", "error");
        return;
      }

      // Guarda el nombre personalizado en localStorage
      localStorage.setItem("nombreJugador", nombre);
      mostrarMensaje("¡Nombre guardado!", "exito");

      // REDIRECCIÓN A LA SIGUIENTE PANTALLA (p. ej. Mapa de niveles)
      setTimeout(function () {
        window.location.href = "pantallaregistro.html";
      }, 1000);
    });
  }
  window.location.href = "pantallaregistro.html";
});