document.addEventListener("DOMContentLoaded", () => {

  // Obtener elementos del DOM
  const formRegistro = document.getElementById("formRegistro");
  const btnVolver = document.getElementById("btnVolver");
  const mensaje = document.getElementById("mensaje");

  // Campos de entrada
  const inputNombre = document.getElementById("nombre");
  const inputCurso = document.getElementById("curso");
  const inputApellido = document.getElementById("apellido");
  const inputGmail = document.getElementById("gmail");
  const inputPassword = document.getElementById("password");
  const inputPassword2 = document.getElementById("password2");

  // Botón volver
  btnVolver.addEventListener("click", () => {
    // Redirecciona a la página anterior o principal
    window.location.href = "index.html";
  });

  // Envío e interacción del formulario
  formRegistro.addEventListener("submit", (e) => {
    e.preventDefault();

    // Limpiar espacios extra
    const nombre = inputNombre.value.trim();
    const curso = inputCurso.value.trim();
    const apellido = inputApellido.value.trim();
    const gmail = inputGmail.value.trim();
    const password = inputPassword.value;
    const password2 = inputPassword2.value;

    // Resetear mensaje de estado
    mostrarMensaje("", "");

    // Validar campos vacíos
    if (!nombre || !curso || !apellido || !gmail || !password || !password2) {
      mostrarMensaje("¡Completa todos los campos!", "error");
      return;
    }

    // Validar formato Gmail
    const formatoEmail = /^[a-zA-Z0-9._%+-]+@gmail\.com$/;
    if (!formatoEmail.test(gmail)) {
      mostrarMensaje("Ingresa un correo de Gmail válido", "error");
      return;
    }

    // Validar contraseñas
    if (password !== password2) {
      mostrarMensaje("Las contraseñas no coinciden", "error");
      return;
    }

    if (password.length < 6) {
      mostrarMensaje("La contraseña debe tener al menos 6 caracteres", "error");
      return;
    }

    // Guardar en LocalStorage
    const usuario = { nombre, curso, apellido, gmail };
    localStorage.setItem("usuarioRegistrado", JSON.stringify(usuario));

    mostrarMensaje("¡Registro exitoso!", "exito");

    // Transición a la pantalla de personalización de nombre
    setTimeout(() => {
      window.location.href = "personalizacion_nombre.html";
    }, 1500);
  });

  function mostrarMensaje(texto, tipo) {
    mensaje.textContent = texto;
    mensaje.className = "mensaje " + tipo;
  }
});